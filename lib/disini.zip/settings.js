/*
Terimakasih Telah Menggunakan Script ini
Base By : Lezz DcodeR
Optimalization By : ErizaOffc

Dukung Kami dengan membiarkan credit ini tetap ada!
*/

const fs = require('fs')
const chalk = require('chalk')

//Settings
global.owner = "628132215713"
global.ownername = "Ganzz Alwayss"
global.namabot = "Ghost Spirit Bot"
global.botversion = "Version 1.0.0"
global.linkgc = "https://chat.whatsapp.com/CqxV8NgZLYF5FR6eSLPc6N"
global.idGc = "120363407513551975@g.us"
global.linkSaluran = "https://whatsapp.com/channel/0029VacUGeBDW0h"
global.idSaluran = "1203632870@newsletter"
global.namaSaluran = global.ownername + " | Saluran WhatsApp"
global.simbol = "⭔"

//Thumbnail
global.imgthumb = "https://files.catbox.moe/xhrbzw.jpg"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})